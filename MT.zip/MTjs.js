const inputFecha = document.getElementById('fecha-objetivo');
const btnIniciar = document.getElementById('btn-iniciar');
const display = {
    dias: document.getElementById('dias'),
    horas: document.getElementById('horas'),
    minutos: document.getElementById('minutos'),
    segundos: document.getElementById('segundos')
};
const mensaje = document.getElementById('mensaje');
let intervalo;
inputFecha.addEventListener('change', () => {
    btnIniciar.disabled = !inputFecha.value;
});

btnIniciar.addEventListener('click', () => {
    const fechaMeta = new Date(inputFecha.value).getTime();
    clearInterval(intervalo);
    intervalo = setInterval(() => {
        const ahora = new Date().getTime();
        const distancia = fechaMeta - ahora;

        if (distancia < 0) {
            clearInterval(intervalo);
            mensaje.innerText = "¡TIEMPO CUMPLIDO!";
            return;
        }
        const d = Math.floor(distancia / (1000 * 60 * 60 * 24));
        const h = Math.floor((distancia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((distancia % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((distancia % (1000 * 60)) / 1000);
        display.dias.innerText = String(d).padStart(2, '0');
        display.horas.innerText = String(h).padStart(2, '0');
        display.minutos.innerText = String(m).padStart(2, '0');
        display.segundos.innerText = String(s).padStart(2, '0');
        if (distancia < 60000) {
            document.getElementById('contador').classList.add('pocotiempo');
        } else {
            document.getElementById('contador').classList.remove('pocotiempo');
        }
    }, 1000);
});
