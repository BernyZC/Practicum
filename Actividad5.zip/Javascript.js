function procesarFormulario() {
    const nombre = document.getElementById('nombre');
    const correo = document.getElementById('correo');
    const fecha = document.getElementById('fecha');
    const color = document.getElementById('colorPicker');
    const rango = document.getElementById('rango');
    const intereses = Array.from(document.querySelectorAll('input[name="interes"]:checked')).map(cb => cb.value);
    const nivel = document.querySelector('input[name="nivel"]:checked');
    if (!nombre.value) return alert("El campo 'Nombre' está vacío.");
    if (!correo.value) return alert("El campo 'Email' está vacío.");
    if (intereses.length === 0) return alert("Selecciona al menos un interés.");
    if (!nivel) return alert("Selecciona un nivel de suscripción.");
    if (!fecha.value) return alert("Selecciona una fecha y hora.");
    const tabla = document.getElementById('tablaDatos').getElementsByTagName('tbody')[0];
    const nuevaFila = tabla.insertRow();
    nuevaFila.innerHTML = `
        <td>${nombre.value}</td>
        <td>${correo.value}</td>
        <td>${intereses.join(', ')}</td>
        <td>${nivel.value}</td>
        <td>${fecha.value.replace('T', ' ')}</td>
        <td><div class="color-box" style="background-color: ${color.value}"></div></td>
        <td>${rango.value}%</td>
    `;
    document.getElementById('registroForm').reset();
}
